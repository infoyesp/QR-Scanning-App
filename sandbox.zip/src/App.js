import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Hello</h1>
      <h2>Welcome to Yesp Product!</h2>
    </div>
  );
}
